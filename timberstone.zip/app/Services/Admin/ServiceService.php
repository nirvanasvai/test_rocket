<?php
namespace App\Services\Admin;

use App\Models\Service;
use App\Models\SliderMain;
use App\Services\ImageUploaderServices;

class ServiceService{

    private $imageUploader;

    public function __construct(){

        $this->imageUploader=new ImageUploaderServices();
    }

    public function create($data)
    {
        if(isset($data['image']))
        {
            $data['image']=$this->imageUploader
                ->save('/main',$data['image'])
                ->getPath();
        }
        Service::query()->create($data);
    }
}
?>


