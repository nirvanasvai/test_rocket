<?php
namespace App\Exports\Sheets;

use Maatwebsite\Excel\Concerns\FromQuery;
use Maatwebsite\Excel\Concerns\WithTitle;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithHeadings;
use App\Models\Category;

class CategoriesSheet implements FromQuery, WithTitle, ShouldAutoSize, WithHeadings
{

    public function headings(): array
    {
        return [
           'Категория','ID Категории','Подкатегория','ID Подкатегории'
        ];
    }

    public function query()
    {
//        $data = Category::query()->whereNull('categories.parent_id')->leftJoin('categories as child', 'child.parent_id', 'categories.id')->select('categories.title as parent_title', 'categories.id as id_parent', 'child.title as child_title','child.id as id_child')->get();

        return Category::query()->whereNull('categories.parent_id')->leftJoin('categories as child', 'child.parent_id', 'categories.id')->select('categories.title as parent_title', 'categories.id as id_parent', 'child.title as child_title','child.id as id_child');
    }

    public function title(): string
    {
        return 'Категории';
    }
}
