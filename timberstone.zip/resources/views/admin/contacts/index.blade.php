@extends('admin.layouts.app')

@section('title','Контакты')

@section('content')
<div class="container-fluid">
    <br>
    <h2>
        Контакты
    </h2>

    @include('admin.components.message')


                <div class="card mt-3">
                    <div class="card-header">
                        <ul class="nav nav-tabs card-header-tabs">
                            <li class="nav-item">
                                <a class="nav-link active" id="info-tab" data-toggle="tab" href="#info" role="tab" aria-controls="info" aria-selected="true"><i class="far fa-address-book"></i> Контакты</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="contacts-tab" data-toggle="tab" href="#contacts" role="tab" aria-controls="contacts" aria-selected="false"><i class="fab fa-instagram"></i> Социльаные Сети</a>
                            </li>
                        </ul>
                    </div>
                    <div class="tab-content" id="myTabContent">

                        <div class="tab-pane fade show active" id="info" role="tabpanel" aria-labelledby="info-tab">
                            @include('admin.contacts.info.index')
                        </div>
                        <div class="tab-pane fade" id="contacts" role="tabpanel" aria-labelledby="contacts-tab">
                            @include('admin.contacts.social.index')
                        </div>
                    </div>
                </div>
            </div>

@endsection
