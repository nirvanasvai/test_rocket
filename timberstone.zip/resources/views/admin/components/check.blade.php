<div class="row">
	<div class="col-sm-6">
		<a href="{{ url()->previous() }}" class="btn btn-primary">Назад</a>
	</div>
	<div class="col-sm-6">
    	<button type="submit" class="btn btn-primary float-right">Сохранить</button>
	</div>
</div>


