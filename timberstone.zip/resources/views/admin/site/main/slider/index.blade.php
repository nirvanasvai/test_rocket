@extends('admin.layouts.app')

@section('title','Слайдеры')

@section('content')

<div class="container-fluid">
    <br>
   <h2>Блок слайдер</h2>
    <br>
                    <div class="card">
                        <div class="card-body">
                            <a href="{{url('/admin/about/main-page')}}" class="btn btn-primary mb-2"> Назад</a>
                            @if(Auth::user()->role==2)
                            <a href="{{ route('slider.create') }}" class="btn btn-primary mb-2"><i class="far fa-plus-square"></i> Создать</a>
                            @endif
                            <div class="table-responsive">
                                <table id="zero_config" class="table table-striped table-bordered no-wrap">
                                    <thead>
                                    <tr>
                                        <th>Наименование</th>
                                        <th class="text-center">Публикация</th>
                                        <th class="text-right">Действие</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @forelse($sliders as $slider)
                                        <tr>
                                            <td>{{ $slider->title }}</td>
                                            <td class="text-center">
                                                <form id="published-form-{{ $slider->id ?? '' }}" class="form-horizontal" action="{{route('slider.update', $slider)}}" method="post">
                                                    @method('PUT')
                                                    @csrf

                                                </form>
                                            </td>
                                            <td class="text-right">
                                                <form onsubmit="if(confirm('Удалить?')){ return true }else{ return false }" action="{{ route('slider.destroy', $slider) }}" method="post">
                                                    @method('DELETE')
                                                    @csrf

                                                    <a class="btn btn-primary" href="{{ route('slider.edit', $slider) }}"><i class="fa fa-edit"></i></a>

                                                    @if(Auth::user()->role==2)
                                                        <button type="submit" class="btn btn-danger"><i class="far fa-trash-alt"></i></button>
                                                    @endif
                                                </form>
                                            </td>
                                            </tr>
                                    @empty
                                        <tr>
                                            <td colspan="3" class="text-center"><h2>Данные отсутствуют</h2></td>
                                        </tr>
                                    @endforelse

                                    </tbody>

                                </table>
                            </div>
                        </div>
                    </div>
@endsection
