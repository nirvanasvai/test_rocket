@extends('layouts.app')

@section('title', 'Избранные - Timberstone')

@section('content')
    <div class="products_wrapper">
        <div class="container">
            <div class="title_block">
                <h1>Избранные товары</h1>
            </div>
            <div class="favorites_wrapper row"></div>
        </div>
    </div>

@endsection
