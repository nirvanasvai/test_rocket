@extends('layouts.app')

@section('title', $blog_info->title_name.' - Timberstone')

@section('content')
    <div class="blogs">
        <div class="container">
            <div class="breadcrumbs">
                <ul>
                    <li><a href="/">Главная</a></li>
                    <li>{{$blog_info->title_name}}</li>
                </ul>
            </div>
            <div class="blog_content_wrapper">
                <div class="show_mobile_category">
                    <p>{{$blog_info->title_name ?? ''}} </p>
                    <i class="fas fa-sort-down"></i>
                </div>
                <div class="row">
                    <div class="col-xl-3 col-lg-4">
                        <div class="blogs_links mobile_blogs_links">
                            <ul>
                                <ul>
                                    @foreach($blogs as $item)
                                        <li>
                                            <a href="#section_{{$item->id}}" class=""><img src="/storage/{{$item->icon ?? ''}}">{{$item->main_title ?? ''}}</a>
                                        </li>
                                    @endforeach
                                </ul>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-9 col-lg-8">
                        <div class="blog_content">
                            <div class="blog_img">
                                <img src="/storage/{{$blog_info->image ?? ''}}" alt="">
                            </div>
                            <div class="title_block">
                                 <h1>{{$blog_info->title_name}}</h1>
                            </div>
                            <div class="blog_text">
                                   {!!$blog_info->advantages ?? ''!!}
                            </div>
                            @foreach ($blogs as $item)
                                <section id="section_{{$item->id}}">
                                    <h2>{{$item->main_title}}</h2>
                                    <div class="blog_img">
                                        <img src="/storage/{{$item->main_image ?? ''}}" alt="">
                                    </div>
                                    <div class="desc">
                                        {!!$item->main_description!!}
                                    </div>
                                </section>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>





@endsection








