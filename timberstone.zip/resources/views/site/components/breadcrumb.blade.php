<ul>
    <li><a href="{{url('/')}}">{{$title}}</a></li>
    <li><a href="#">{{$parent}}</a></li>
    <li class="active_link"><a href="#" >{{$active}}</a></li>
</ul>
