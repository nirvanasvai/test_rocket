<?php

namespace App\Services\Site;



class PartnersService
{
    public function getALlPagedata()
    {


        return $data;

    }
}
?>
