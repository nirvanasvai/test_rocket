<script>
	alert('hi!');
</script>